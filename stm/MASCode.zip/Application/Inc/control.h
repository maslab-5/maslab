#ifndef INC_CONTROL_H_
#define INC_CONTROL_H_

void Control_Init(void);
void Control_Loop(void);

#endif
