#ifndef INC_MOVEMENT_H_
#define INC_MOVEMENT_H_

#include "inttypes.h"

enum MoveState {
	RampUp,
	Constant,
	RampDown
};

enum MoveType {
	Line,
	Rotate,
};

//arcs later maybe

struct MoveProfile {
	float maxAccel;
	float maxSpeed;
};

void initMove(struct MoveProfile profile);

void updateMove(uint32_t time);
void move(enum MoveType type, float amount, uint8_t direction);
void stopMovement(void);

#endif
