#ifndef INC_DRIVERS_ENCODERS_H_
#define INC_DRIVERS_ENCODERS_H_

#include "drivers/motors.h"
#include "inttypes.h"

void initEncoders(void);

int32_t getPosition(enum LargeMotor motor);
void resetPosition(enum LargeMotor motor);

void encoderHandler(uint8_t value);

#endif
