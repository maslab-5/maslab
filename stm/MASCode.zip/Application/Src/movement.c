#include "movement.h"
#include "inttypes.h"

static struct MoveProfile moveProf;
static struct rampTime;
static struct rampDistance;

static enum MoveState moveState;

static enum MoveType moveType;

static uint8_t moving = 1;
static uint32_t startTime;

static float moveAmount;
static float moveDirection;

void initMove(struct MoveProfile profile) {
	moving = 0;
	moveProf = profile;

}
void updateMove(uint32_t time) {
	switch (moveType) {
	case Line:
		break;
	case Rotate:
		break;
	default:
		break;
	}
}

void move(enum MoveType type, float amount, uint8_t direction) {
	if (moving) {
		return;
	}

	moveType = type;
	moveAmount = amount;
	moveDirection = direction;
}

void stopMovement(void) {

}
