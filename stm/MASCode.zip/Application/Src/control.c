#include <drivers/motors.h>
#include "control.h"
#include "main.h"
#include "drivers/registers.h"
#include "drivers/encoders.h"
#include "drivers/PID.h"
#include "drivers/servos.h"
#include "lib/ssd1306.h"
#include <string.h>
#include <stdio.h>
#include "math.h"

static uint32_t startTime = 0;
static uint32_t lastFrame = 0;

void Control_Init(void) {
	initRegisters();
	initMotors();
	HAL_Delay(10);
	initEncoders();
	initServos();
	moveServo(CameraServo, 0);
	//	ssd1306_Init();

	struct PidParam motorPID = {90, 0.7, 0.1, 0.04};

	initPID(LeftMotor, motorPID);
	initPID(RightMotor, motorPID);

	setMotorEnable(LeftMotor, 1);
	setMotorEnable(RightMotor, 1);
	setMotorEnable(ChuteMotor, 1);

	setMotorCurrent(LeftMotor, 30);
	setMotorCurrent(RightMotor, 30);
	setMotorCurrent(ChuteMotor, 1);

//	setDirection(ChuteMotor, 1);
//	setSpeed(ChuteMotor, 100);
//	HAL_Delay(4000);
//	setDirection(ChuteMotor, 0);
//	HAL_Delay(4000);
//	setEnable(ChuteMotor, 0);
	//reset encoder positions before start
//	startTime = HAL_GetTick();

	motorMove(GateMotor, 0, 100);
	HAL_Delay(2000);
	motorMove(GateMotor, 0, 0);
	HAL_Delay(2000);
	motorMove(GateMotor, 100, 0);
	HAL_Delay(2000);
	motorMove(GateMotor, 0, 0);
}

void Control_Loop(void) {
//	uint32_t error = getPosition(motor)
//	float accel = 0.002;
//	float speed = 1;
//
//	uint32_t time = HAL_GetTick();
//	uint32_t dt = time - startTime;
//	float dFrame = ((float)(time - lastFrame))/1.0e3;
//	uint32_t pos;
//
//	if (dt < 500) {
//		pos = dt*dt*accel/2;
//	}else {
//		pos = 500*500*accel/2;
//		pos += (dt-500)*speed;
//	}
//	if (dt > 3000) {
//		setEnable(LeftMotor, 0);
//		setEnable(RightMotor, 0);
//	}else{
//		updatePID(LeftMotor, pos, dFrame);
//		updatePID(RightMotor, -pos, dFrame);
//	}
//
//	lastFrame = time;
//
//	moveServo(CameraServo, 0);
//	HAL_Delay(1000);
//	moveServo(CameraServo, 400);
//	HAL_Delay(1000);
}
