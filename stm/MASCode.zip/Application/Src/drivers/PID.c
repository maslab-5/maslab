#include "drivers/PID.h"
#include "drivers/encoders.h"
#include <stdlib.h>
#include "math.h"

struct PidParam params[4];
int32_t errPrev[4];
float errInt[4];

void initPID(enum LargeMotor motor, struct PidParam param) {
	params[motor] = param;
	errPrev[motor] = 0;
	errInt[motor] = 0.0;
}

void updatePID(enum LargeMotor motor, int32_t target, float dt) {
	const struct PidParam param = params[motor];
	int32_t err = getPosition(motor) - target;
	float errDeriv = ((float)(err - errPrev[motor])) / dt;
	errInt[motor] += ((float)err) * dt;
	float drive = (param.kp * ((float)err)) + (param.kd * errDeriv) + (param.ki * errInt[motor]);

	errPrev[motor] = err;

	uint8_t dir = 0;
	if (drive > 0) {
		dir = 1;
	}
	uint8_t speed = fabs(drive);
	if (speed > param.maxSpeed) {
		speed = param.maxSpeed;
	}

	setDirection(motor, dir);
	setSpeed(motor, speed);
}
