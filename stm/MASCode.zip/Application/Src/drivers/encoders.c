#include "drivers/encoders.h"
#include "drivers/registers.h"
#include <string.h>

static uint8_t lastState = 0;
static int32_t encoders[4] = {0};

void initEncoders(void) {
	lastState = readRegister(EncoderRegister);
}

int32_t getPosition(enum LargeMotor motor) {
	return encoders[motor];
}

void resetPosition(enum LargeMotor motor) {
	encoders[motor] = 0;
}

static void channelHandler(uint8_t channel, uint8_t current, uint8_t last) {
	uint8_t change = current^last;
	last >>= 1;
	if ((change & current) == 1) {
		if (last) {
			encoders[channel]++;
		}else{
			encoders[channel]--;
		}
	}
}

void encoderHandler(uint8_t state) {
	if (lastState == state) {
		return;
	}
	uint8_t tempState = state;
	for (uint8_t chan = 0; chan < 4; chan++) {
		uint8_t current = state&0x03;
		uint8_t last = lastState&0x03;
		if (current^last) {
			channelHandler(3-chan, current, last);
		}
		state >>= 2;
		lastState >>= 2;
	}
	lastState = tempState;
}
