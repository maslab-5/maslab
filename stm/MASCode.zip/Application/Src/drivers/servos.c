#include "drivers/servos.h"
#include "main.h"

extern TIM_HandleTypeDef htim1;

static uint16_t channels[4];

void initServos(void) {
	channels[0] = TIM_CHANNEL_1;
	channels[1] = TIM_CHANNEL_2;
	channels[2] = TIM_CHANNEL_3;
	channels[3] = TIM_CHANNEL_4;

	for (uint8_t chan = 0; chan < 4; chan++) {
		HAL_TIM_PWM_Start(&htim1, channels[chan]);
	}
}

//0-500
void moveServo(enum Servo servo, uint16_t position) {
	__HAL_TIM_SET_COMPARE(&htim1, channels[servo], position+500);
}
