#include "commands.h"


/* HEADERS */
//NUC
//0xxxxxxx send
//1xxxxxxx request

//STM32
//0xxxxxxx send
//1xxxxxxx reply

/* COMMANDS */
//-> move line
//-> move rotate
//-> move spin wheel
//-> move stop

//<- isMoving

//-> move camera
//-> open gate
//-> close gate

//<- isGateMoving

//-> chute down
//-> chute up

//<- isChuteMoving
